# Lana Lanches

## Estrutura

- `/` Loja do cliente
- `/admin` Painel administrativo
- Supabase para banco e autenticação
- Vercel para hospedagem
- GitHub para versionamento

## 1. Supabase

Crie um projeto no Supabase.

Abra o SQL Editor e execute o arquivo:

schema.sql

## 2. Criar login do Admin

No Supabase:

Authentication > Users > Add user

Crie o e-mail e senha que serão usados em:

/admin

## 3. Configurar o site

Abra:

js/config.js

Substitua:

COLE_AQUI_SUA_SUPABASE_URL

COLE_AQUI_SUA_ANON_KEY

Use somente a chave ANON/PUBLISHABLE do Supabase.

Nunca use a service_role no navegador.

## 4. GitHub

Crie um repositório e envie todos os arquivos deste projeto.

## 5. Vercel

No Vercel:

Add New > Project > Import Git Repository

Selecione o repositório.

Framework Preset:
Other

Build Command:
deixe vazio

Output Directory:
deixe vazio

Clique em Deploy.

## Links

Cliente:
https://seu-projeto.vercel.app/

Admin:
https://seu-projeto.vercel.app/admin
