const categoryOrder = [
  "Cachorro-quente",
  "Pastéis",
  "Caldos",
  "Porções"
];

const money = value =>
  new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL"
  }).format(value || 0);

const el = id => document.getElementById(id);

let products = [];
let neighborhoods = [];

async function checkSession() {
  const { data } = await db.auth.getSession();

  if (data.session) {
    showPanel();
  }
}

el("login-btn").addEventListener(
  "click",
  async () => {
    el("login-error").textContent = "";

    const email = el("email").value.trim();
    const password = el("password").value;

    const { error } =
      await db.auth.signInWithPassword({
        email,
        password
      });

    if (error) {
      el("login-error").textContent =
        "E-mail ou senha inválidos.";
      return;
    }

    showPanel();
  }
);

el("logout-btn").addEventListener(
  "click",
  async () => {
    await db.auth.signOut();

    el("admin-panel").classList.add("hidden");
    el("login-card").classList.remove("hidden");
  }
);

async function showPanel() {
  el("login-card").classList.add("hidden");
  el("admin-panel").classList.remove("hidden");

  await Promise.all([
    loadStore(),
    loadProducts(),
    loadNeighborhoods(),
    loadOrders()
  ]);
}

async function loadStore() {
  const { data, error } = await db
    .from("store_settings")
    .select("*")
    .eq("id", 1)
    .single();

  if (error) {
    console.error(error);
    return;
  }

  if (!data) return;

  const text =
    data.status === "open"
      ? "🟢 Loja aberta"
      : data.status === "paused"
        ? "🟡 Pedidos pausados"
        : "🔴 Loja fechada";

  el("admin-store-text").textContent = text;
}

document
  .querySelectorAll("[data-store-status]")
  .forEach(btn => {
    btn.addEventListener("click", async () => {
      const { error } = await db
        .from("store_settings")
        .update({
          status: btn.dataset.storeStatus,
          updated_at: new Date().toISOString()
        })
        .eq("id", 1);

      if (error) {
        console.error(error);
        return;
      }

      loadStore();
    });
  });

async function loadProducts() {
  const { data, error } = await db
    .from("products")
    .select("*")
    .order("sort_order");

  if (error) {
    console.error(error);
    return;
  }

  products = data || [];

  el("admin-products").innerHTML =
    categoryOrder
      .map(
        cat => `
          <div class="admin-category">
            <h3>${cat}</h3>

            ${products
              .filter(p => p.category === cat)
              .map(
                p => `
                  <label class="admin-product">
                    <span>
                      <strong>${p.name}</strong><br>
                      <small>${money(p.price)}</small>
                    </span>

                    <input
                      type="checkbox"
                      data-product-toggle="${p.id}"
                      ${p.active ? "checked" : ""}
                    >
                  </label>
                `
              )
              .join("")}
          </div>
        `
      )
      .join("");

  document
    .querySelectorAll("[data-product-toggle]")
    .forEach(input => {
      input.addEventListener("change", async () => {
        const { error } = await db
          .from("products")
          .update({
            active: input.checked
          })
          .eq(
            "id",
            Number(input.dataset.productToggle)
          );

        if (error) {
          console.error(error);
          input.checked = !input.checked;
        }
      });
    });
}

async function loadNeighborhoods() {
  const { data, error } = await db
    .from("neighborhoods")
    .select("*")
    .order("name");

  if (error) {
    console.error(error);
    return;
  }

  neighborhoods = data || [];

  el("admin-neighborhoods").innerHTML =
    neighborhoods.length
      ? neighborhoods
          .map(
            n => `
              <div class="admin-neighborhood">
                <div>
                  <strong>${n.name}</strong><br>
                  <small>
                    ${money(n.fee)}
                    •
                    ${n.active ? "Ativo" : "Desativado"}
                  </small>
                </div>

                <button
                  class="secondary-btn"
                  data-neighborhood-toggle="${n.id}"
                  data-active="${n.active}"
                >
                  ${n.active ? "Desativar" : "Ativar"}
                </button>
              </div>
            `
          )
          .join("")
      : "<p>Nenhum bairro cadastrado.</p>";

  document
    .querySelectorAll("[data-neighborhood-toggle]")
    .forEach(btn => {
      btn.addEventListener("click", async () => {
        const active =
          btn.dataset.active === "true";

        const { error } = await db
          .from("neighborhoods")
          .update({
            active: !active
          })
          .eq(
            "id",
            Number(btn.dataset.neighborhoodToggle)
          );

        if (error) {
          console.error(error);
          return;
        }

        loadNeighborhoods();
      });
    });
}

el("add-neighborhood-btn").addEventListener(
  "click",
  async () => {
    const name =
      el("new-neighborhood").value.trim();

    const fee =
      Number(el("new-fee").value);

    if (
      !name ||
      !Number.isFinite(fee) ||
      fee < 0
    ) {
      return;
    }

    const { error } = await db
      .from("neighborhoods")
      .insert({
        name,
        fee,
        active: true
      });

    if (error) {
      console.error(error);
      return;
    }

    el("new-neighborhood").value = "";
    el("new-fee").value = "";

    loadNeighborhoods();
  }
);

async function loadOrders() {
  const { data, error } = await db
    .from("orders")
    .select(`
      *,
      neighborhood:neighborhoods(name),
      items:order_items(*)
    `)
    .order("created_at", {
      ascending: false
    })
    .limit(100);

  if (error) {
    console.error(error);
    return;
  }

  const orders = data || [];

  el("orders").innerHTML =
    orders.length
      ? orders
          .map(
            o => `
              <div class="order-card">
                <div class="order-head">
                  <div>
                    <strong>Pedido #${o.id}</strong>
                    <div>
                      <small>
                        ${new Date(
                          o.created_at
                        ).toLocaleString("pt-BR")}
                      </small>
                    </div>
                  </div>

                  <div>
                    <span class="badge">
                      ${labelStatus(o.status)}
                    </span>
                    <br>
                    <strong>${money(o.total)}</strong>
                  </div>
                </div>

                <p>
                  <strong>${o.customer_name}</strong>
                  •
                  ${o.customer_phone}
                </p>

                <p>
                  ${
                    o.fulfillment === "delivery"
                      ? `Delivery • ${o.neighborhood?.name || ""} • ${o.street || ""}, ${o.number || ""}`
                      : "Retirada"
                  }
                </p>

                <p>
                  ${(o.items || [])
                    .map(
                      item =>
                        `${item.qty}x ${item.name}`
                    )
                    .join(" • ")}
                </p>

                ${
                  o.notes
                    ? `<p><strong>Obs.:</strong> ${o.notes}</p>`
                    : ""
                }

                <div class="order-actions">
                  <button
                    class="secondary-btn"
                    data-order-status="${o.id}"
                    data-next="preparing"
                  >
                    Em preparo
                  </button>

                  <button
                    class="secondary-btn"
                    data-order-status="${o.id}"
                    data-next="ready"
                  >
                    Pronto
                  </button>

                  <button
                    class="secondary-btn"
                    data-order-status="${o.id}"
                    data-next="delivering"
                  >
                    Saiu para entrega
                  </button>

                  <button
                    class="secondary-btn"
                    data-order-status="${o.id}"
                    data-next="completed"
                  >
                    Finalizado
                  </button>
                </div>
              </div>
            `
          )
          .join("")
      : "<p>Nenhum pedido recebido ainda.</p>";

  document
    .querySelectorAll("[data-order-status]")
    .forEach(btn => {
      btn.addEventListener(
        "click",
        async () => {
          const { error } = await db
            .from("orders")
            .update({
              status: btn.dataset.next
            })
            .eq(
              "id",
              Number(btn.dataset.orderStatus)
            );

          if (error) {
            console.error(error);
            return;
          }

          loadOrders();
        }
      );
    });
}

function labelStatus(status) {
  return (
    {
      received: "Recebido",
      preparing: "Em preparo",
      ready: "Pronto",
      delivering: "Saiu para entrega",
      completed: "Finalizado",
      cancelled: "Cancelado"
    }[status] || status
  );
}

setInterval(() => {
  if (
    !el("admin-panel").classList.contains(
      "hidden"
    )
  ) {
    loadOrders();
  }
}, 15000);

checkSession();
